// CourseHub — Free Courses, Methods, Offers & Coupons for online workers.
// Content comes from the "CourseHub Data" Google Sheet (edited by the owner);
// a bundled seed (assets/seed.json) is used whenever the sheet cannot be read.
// Courses are YouTube links only — nothing is downloaded or re-hosted.
import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show Clipboard, ClipboardData, rootBundle;
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String kSheetId = '1AMq3Aj8D8yYRMBqC_7_MWWufnPSDAX33KNfpHNu5Sy8';
const String kAdLink = 'https://uplcm.com/4/12269238';

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
class CourseItem {
  final String title, channel, category, language, duration, url;
  final DateTime? dateAdded;
  const CourseItem({
    required this.title,
    required this.channel,
    required this.category,
    required this.language,
    required this.duration,
    required this.url,
    this.dateAdded,
  });
  String get languageLabel => language == 'ur' ? 'Urdu/Hindi' : 'English';
  String? get videoId {
    final m = RegExp(r'(?:v=|youtu\.be/|/shorts/|/embed/)([A-Za-z0-9_-]{11})')
        .firstMatch(url);
    return m?.group(1);
  }

  bool get isNew => _isNew(dateAdded);
}

class MethodItem {
  final String title, summary;
  final List<String> steps;
  final DateTime? dateAdded;
  const MethodItem({
    required this.title,
    required this.summary,
    required this.steps,
    this.dateAdded,
  });
  bool get isNew => _isNew(dateAdded);
}

class OfferItem {
  final String tool, whatFree, expiry, url;
  final DateTime? dateAdded;
  const OfferItem({
    required this.tool,
    required this.whatFree,
    required this.expiry,
    required this.url,
    this.dateAdded,
  });
  bool get isNew => _isNew(dateAdded);
}

class CouponItem {
  final String store, code, description, expiry;
  final DateTime? dateAdded;
  const CouponItem({
    required this.store,
    required this.code,
    required this.description,
    required this.expiry,
    this.dateAdded,
  });
  bool get isNew => _isNew(dateAdded);
}

class HubData {
  final List<CourseItem> courses;
  final List<MethodItem> methods;
  final List<OfferItem> offers;
  final List<CouponItem> coupons;
  final bool fromSheet;
  const HubData({
    required this.courses,
    required this.methods,
    required this.offers,
    required this.coupons,
    required this.fromSheet,
  });
}

bool _isNew(DateTime? d) {
  if (d == null) return false;
  final now = DateTime.now();
  if (d.isAfter(now.add(const Duration(days: 1)))) return false;
  return now.difference(d) <= const Duration(days: 7);
}

DateTime? _parseDate(dynamic v) {
  if (v == null) return null;
  final s = v.toString().trim();
  if (s.isEmpty) return null;
  final iso = RegExp(r'(\d{4})-(\d{1,2})-(\d{1,2})').firstMatch(s);
  if (iso != null) {
    return DateTime(
      int.parse(iso.group(1)!),
      int.parse(iso.group(2)!),
      int.parse(iso.group(3)!),
    );
  }
  // gviz serialises real dates as Date(year, month0based, day, ...)
  final gv = RegExp(r'Date\((\d{4}),(\d{1,2}),(\d{1,2})').firstMatch(s);
  if (gv != null) {
    return DateTime(
      int.parse(gv.group(1)!),
      int.parse(gv.group(2)!) + 1,
      int.parse(gv.group(3)!),
    );
  }
  return DateTime.tryParse(s);
}

// ---------------------------------------------------------------------------
// Data loading — Google Sheet (gviz JSON) with bundled-seed fallback
// ---------------------------------------------------------------------------
class DataService {
  static Future<HubData> load() async {
    try {
      final data = await _loadFromSheet();
      if (data.courses.isNotEmpty) return data;
    } catch (_) {
      // fall through to the bundled seed
    }
    return _loadFromSeed();
  }

  static Future<List<List<String>>> _fetchTab(String tab) async {
    final uri = Uri.parse(
      'https://docs.google.com/spreadsheets/d/$kSheetId/gviz/tq'
      '?tqx=out:json&headers=1&sheet=${Uri.encodeComponent(tab)}',
    );
    final res = await http.get(uri).timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) {
      throw Exception('sheet fetch failed: ${res.statusCode}');
    }
    final body = res.body;
    final start = body.indexOf('{');
    final end = body.lastIndexOf('}');
    if (start < 0 || end <= start) throw Exception('bad gviz payload');
    final decoded = jsonDecode(body.substring(start, end + 1)) as Map;
    final table = decoded['table'] as Map?;
    final rows = (table?['rows'] as List?) ?? const [];
    final out = <List<String>>[];
    for (final r in rows) {
      final cells = (r as Map)['c'] as List?;
      if (cells == null) continue;
      final row = <String>[];
      for (final c in cells) {
        if (c == null) {
          row.add('');
        } else {
          final v = (c as Map)['v'];
          row.add(v == null ? '' : v.toString());
        }
      }
      out.add(row);
    }
    return out;
  }

  static String _cell(List<String> row, int i) =>
      i < row.length ? row[i].trim() : '';

  static Future<HubData> _loadFromSheet() async {
    final courseRows = await _fetchTab('Courses');
    final methodRows = await _fetchTab('Methods');
    final offerRows = await _fetchTab('Offers');
    final couponRows = await _fetchTab('Coupons');

    final courses = <CourseItem>[];
    for (final r in courseRows) {
      final title = _cell(r, 0);
      if (title.isEmpty || title == 'Title') continue;
      courses.add(CourseItem(
        title: title,
        channel: _cell(r, 1),
        category: _cell(r, 2).isEmpty ? 'General' : _cell(r, 2),
        language: _cell(r, 3).toLowerCase().startsWith('u') ? 'ur' : 'en',
        duration: _cell(r, 4),
        url: _cell(r, 5),
        dateAdded: _parseDate(_cell(r, 6)),
      ));
    }
    final methods = <MethodItem>[];
    for (final r in methodRows) {
      final title = _cell(r, 0);
      if (title.isEmpty || title == 'Title') continue;
      methods.add(MethodItem(
        title: title,
        summary: _cell(r, 1),
        steps: _cell(r, 2)
            .split('\n')
            .map((s) => s.trim())
            .where((s) => s.isNotEmpty)
            .toList(),
        dateAdded: _parseDate(_cell(r, 3)),
      ));
    }
    final offers = <OfferItem>[];
    for (final r in offerRows) {
      final tool = _cell(r, 0);
      if (tool.isEmpty || tool == 'Tool') continue;
      offers.add(OfferItem(
        tool: tool,
        whatFree: _cell(r, 1),
        expiry: _cell(r, 2),
        url: _cell(r, 3),
        dateAdded: _parseDate(_cell(r, 4)),
      ));
    }
    final coupons = <CouponItem>[];
    for (final r in couponRows) {
      final store = _cell(r, 0);
      if (store.isEmpty || store == 'Store') continue;
      coupons.add(CouponItem(
        store: store,
        code: _cell(r, 1),
        description: _cell(r, 2),
        expiry: _cell(r, 3),
        dateAdded: _parseDate(_cell(r, 4)),
      ));
    }
    return HubData(
      courses: courses,
      methods: methods,
      offers: offers,
      coupons: coupons,
      fromSheet: true,
    );
  }

  static Future<HubData> _loadFromSeed() async {
    final raw = await rootBundle.loadString('assets/seed.json');
    final j = jsonDecode(raw) as Map<String, dynamic>;
    List<Map<String, dynamic>> items(String key) =>
        ((j[key] as List?) ?? const [])
            .map((e) => (e as Map).cast<String, dynamic>())
            .toList();
    return HubData(
      courses: items('courses')
          .map((m) => CourseItem(
                title: '${m['title'] ?? ''}',
                channel: '${m['channel'] ?? ''}',
                category: '${m['category'] ?? 'General'}',
                language: '${m['language'] ?? 'en'}',
                duration: '${m['duration'] ?? ''}',
                url: '${m['url'] ?? ''}',
                dateAdded: _parseDate(m['dateAdded']),
              ))
          .toList(),
      methods: items('methods')
          .map((m) => MethodItem(
                title: '${m['title'] ?? ''}',
                summary: '${m['summary'] ?? ''}',
                steps: ((m['steps'] as List?) ?? const [])
                    .map((e) => '$e')
                    .toList(),
                dateAdded: _parseDate(m['dateAdded']),
              ))
          .toList(),
      offers: items('offers')
          .map((m) => OfferItem(
                tool: '${m['tool'] ?? ''}',
                whatFree: '${m['whatFree'] ?? ''}',
                expiry: '${m['expiry'] ?? ''}',
                url: '${m['url'] ?? ''}',
                dateAdded: _parseDate(m['dateAdded']),
              ))
          .toList(),
      coupons: items('coupons')
          .map((m) => CouponItem(
                store: '${m['store'] ?? ''}',
                code: '${m['code'] ?? ''}',
                description: '${m['description'] ?? ''}',
                expiry: '${m['expiry'] ?? ''}',
                dateAdded: _parseDate(m['dateAdded']),
              ))
          .toList(),
      fromSheet: false,
    );
  }
}

// ---------------------------------------------------------------------------
// Ad break — full-screen web ad (Monetag Direct Link). No ads SDK anywhere.
// Shown once after app start and before opening a course/offer (throttled).
// ---------------------------------------------------------------------------
class AdGate {
  static DateTime? _lastShown;

  static Future<void> maybeShow(BuildContext context) async {
    final last = _lastShown;
    if (last != null && DateTime.now().difference(last).inSeconds < 60) return;
    _lastShown = DateTime.now();
    if (!context.mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const AdBreakPage()),
    );
  }
}

class AdBreakPage extends StatefulWidget {
  const AdBreakPage({super.key});
  @override
  State<AdBreakPage> createState() => _AdBreakPageState();
}

class _AdBreakPageState extends State<AdBreakPage> {
  late final WebViewController _ctrl;
  Timer? _ticker;
  int _secondsLeft = 5;
  bool _canClose = false;

  @override
  void initState() {
    super.initState();
    _ctrl = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onNavigationRequest: (req) {
          final u = req.url;
          if (u.startsWith('http://') || u.startsWith('https://')) {
            return NavigationDecision.navigate;
          }
          return NavigationDecision.prevent;
        },
      ))
      ..loadRequest(Uri.parse(kAdLink));
    _ticker = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      setState(() {
        if (_secondsLeft > 0) _secondsLeft--;
        if (_secondsLeft <= 0) {
          _canClose = true;
          t.cancel();
        }
      });
    });
    Future.delayed(const Duration(seconds: 30), () {
      if (mounted) Navigator.of(context).pop();
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Advertisement'),
        automaticallyImplyLeading: false,
        actions: [
          TextButton(
            onPressed: _canClose ? () => Navigator.of(context).pop() : null,
            child: Text(_canClose ? 'Close ✕' : 'Close in $_secondsLeft…'),
          ),
        ],
      ),
      body: WebViewWidget(controller: _ctrl),
    );
  }
}

// ---------------------------------------------------------------------------
// Link opening — external app first (YouTube app / browser), WebView fallback
// ---------------------------------------------------------------------------
Future<void> openLink(BuildContext context, String url) async {
  final uri = Uri.tryParse(url);
  if (uri == null) return;
  var ok = false;
  try {
    ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
  } catch (_) {
    ok = false;
  }
  if (!ok && context.mounted) {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => WebPage(url: url)),
    );
  }
}

class WebPage extends StatefulWidget {
  final String url;
  const WebPage({super.key, required this.url});
  @override
  State<WebPage> createState() => _WebPageState();
}

class _WebPageState extends State<WebPage> {
  late final WebViewController _ctrl;
  @override
  void initState() {
    super.initState();
    _ctrl = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('CourseHub')),
      body: WebViewWidget(controller: _ctrl),
    );
  }
}

// ---------------------------------------------------------------------------
// App
// ---------------------------------------------------------------------------
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CourseHubApp());
}

class CourseHubApp extends StatelessWidget {
  const CourseHubApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CourseHub',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late final Future<HubData> _future;
  int _tab = 0;
  bool _startAdShown = false;

  @override
  void initState() {
    super.initState();
    _future = DataService.load();
    _future.whenComplete(() {
      if (_startAdShown) return;
      _startAdShown = true;
      Future.delayed(const Duration(milliseconds: 1500), () {
        if (mounted) AdGate.maybeShow(context);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CourseHub'),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            onPressed: () => showAboutDialog(
              context: context,
              applicationName: 'CourseHub',
              applicationVersion: '1.0.0',
              children: const [
                Text(
                  'Free courses, earning methods, offers and coupons for '
                  'online workers. Courses play on YouTube — tap any course '
                  'to open it there.',
                ),
              ],
            ),
          ),
        ],
      ),
      body: FutureBuilder<HubData>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snap.data ??
              const HubData(
                courses: [],
                methods: [],
                offers: [],
                coupons: [],
                fromSheet: false,
              );
          switch (_tab) {
            case 1:
              return MethodsTab(methods: data.methods);
            case 2:
              return OffersTab(offers: data.offers);
            case 3:
              return CouponsTab(coupons: data.coupons);
            default:
              return CoursesTab(courses: data.courses);
          }
        },
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.play_lesson_outlined),
            selectedIcon: Icon(Icons.play_lesson),
            label: 'Courses',
          ),
          NavigationDestination(
            icon: Icon(Icons.route_outlined),
            selectedIcon: Icon(Icons.route),
            label: 'Methods',
          ),
          NavigationDestination(
            icon: Icon(Icons.card_giftcard_outlined),
            selectedIcon: Icon(Icons.card_giftcard),
            label: 'Offers',
          ),
          NavigationDestination(
            icon: Icon(Icons.discount_outlined),
            selectedIcon: Icon(Icons.discount),
            label: 'Coupons',
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Shared bits
// ---------------------------------------------------------------------------
class NewBadge extends StatelessWidget {
  const NewBadge({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: Colors.red.shade600,
        borderRadius: BorderRadius.circular(6),
      ),
      child: const Text(
        'NEW',
        style: TextStyle(
          color: Colors.white,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

IconData categoryIcon(String category) {
  final c = category.toLowerCase();
  if (c.contains('python') || c.contains('programming')) return Icons.code;
  if (c.contains('web')) return Icons.web;
  if (c.contains('flutter') || c.contains('app')) return Icons.phone_android;
  if (c.contains('freelanc')) return Icons.work_outline;
  if (c.contains('marketing')) return Icons.campaign_outlined;
  if (c.contains('design')) return Icons.brush_outlined;
  if (c.contains('video') || c.contains('editing')) return Icons.movie_outlined;
  if (c.contains('ai') || c.contains('artificial')) return Icons.smart_toy_outlined;
  if (c.contains('amazon') || c.contains('earning')) return Icons.attach_money;
  if (c.contains('excel') || c.contains('office')) return Icons.table_chart_outlined;
  if (c.contains('english') || c.contains('speaking')) return Icons.record_voice_over_outlined;
  if (c.contains('data')) return Icons.bar_chart_outlined;
  if (c.contains('hack') || c.contains('security') || c.contains('cyber')) {
    return Icons.security_outlined;
  }
  if (c.contains('wordpress')) return Icons.language_outlined;
  if (c.contains('youtube')) return Icons.ondemand_video_outlined;
  return Icons.school_outlined;
}

// ---------------------------------------------------------------------------
// Courses tab — search + language filter + category grid → course list
// ---------------------------------------------------------------------------
class CoursesTab extends StatefulWidget {
  final List<CourseItem> courses;
  const CoursesTab({super.key, required this.courses});
  @override
  State<CoursesTab> createState() => _CoursesTabState();
}

class _CoursesTabState extends State<CoursesTab> {
  String _query = '';
  String _lang = 'all';
  String? _category;

  List<CourseItem> get _filtered {
    return widget.courses.where((c) {
      if (_lang != 'all' && c.language != _lang) return false;
      if (_category != null && c.category != _category) return false;
      if (_query.isNotEmpty) {
        final q = _query.toLowerCase();
        final hay =
            '${c.title} ${c.channel} ${c.category}'.toLowerCase();
        if (!hay.contains(q)) return false;
      }
      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final showGrid = _category == null && _query.isEmpty;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Search courses, channels, topics…',
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              isDense: true,
            ),
            onChanged: (v) => setState(() => _query = v.trim()),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          child: Row(
            children: [
              for (final entry in const [
                ('all', 'All'),
                ('en', 'English'),
                ('ur', 'Urdu/Hindi'),
              ])
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(entry.$2),
                    selected: _lang == entry.$1,
                    onSelected: (_) => setState(() => _lang = entry.$1),
                  ),
                ),
              const Spacer(),
              Text(
                '${_filtered.length} courses',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
        if (_category != null)
          ListTile(
            leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () => setState(() => _category = null),
            ),
            title: Text(
              _category!,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: const Text('Tap a course to open it on YouTube'),
          ),
        Expanded(
          child: showGrid ? _categoryGrid() : _courseList(),
        ),
      ],
    );
  }

  Widget _categoryGrid() {
    final counts = <String, int>{};
    for (final c in widget.courses) {
      if (_lang != 'all' && c.language != _lang) continue;
      counts[c.category] = (counts[c.category] ?? 0) + 1;
    }
    final cats = counts.keys.toList()..sort();
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.45,
      ),
      itemCount: cats.length + 1,
      itemBuilder: (context, i) {
        if (i == 0) {
          return _categoryCard(
            icon: Icons.grid_view_rounded,
            name: 'All Courses',
            count: widget.courses.length,
            onTap: () => setState(() => _query = ' '),
          );
        }
        final cat = cats[i - 1];
        return _categoryCard(
          icon: categoryIcon(cat),
          name: cat,
          count: counts[cat]!,
          onTap: () => setState(() => _category = cat),
        );
      },
    );
  }

  Widget _categoryCard({
    required IconData icon,
    required String name,
    required int count,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 1,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 30, color: Colors.indigo),
              const SizedBox(height: 10),
              Text(
                name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                ),
              ),
              Text(
                '$count courses',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _courseList() {
    final list = _filtered;
    if (list.isEmpty) {
      return const Center(
        child: Text('No courses found. Try another search.'),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      itemCount: list.length,
      itemBuilder: (context, i) => CourseTile(course: list[i]),
    );
  }
}

class CourseTile extends StatelessWidget {
  final CourseItem course;
  const CourseTile({super.key, required this.course});

  @override
  Widget build(BuildContext context) {
    final id = course.videoId;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () async {
          await AdGate.maybeShow(context);
          if (context.mounted) await openLink(context, course.url);
        },
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 132,
              height: 96,
              child: id != null
                  ? Image.network(
                      'https://img.youtube.com/vi/$id/hqdefault.jpg',
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _thumbFallback(),
                    )
                  : _thumbFallback(),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            course.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 14,
                            ),
                          ),
                        ),
                        if (course.isNew) ...[
                          const SizedBox(width: 6),
                          const NewBadge(),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      course.channel,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        _miniChip(Icons.folder_outlined, course.category),
                        _miniChip(Icons.language, course.languageLabel),
                        if (course.duration.isNotEmpty)
                          _miniChip(Icons.schedule, course.duration),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _thumbFallback() {
    return Container(
      color: Colors.indigo.shade100,
      child: const Center(
        child: Icon(Icons.play_circle_fill, size: 44, color: Colors.indigo),
      ),
    );
  }

  Widget _miniChip(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: Colors.indigo.withOpacity(0.08),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: Colors.indigo),
          const SizedBox(width: 3),
          Text(label, style: const TextStyle(fontSize: 11)),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Methods tab
// ---------------------------------------------------------------------------
class MethodsTab extends StatelessWidget {
  final List<MethodItem> methods;
  const MethodsTab({super.key, required this.methods});

  @override
  Widget build(BuildContext context) {
    if (methods.isEmpty) {
      return const Center(child: Text('No methods yet. Check back soon.'));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: methods.length,
      itemBuilder: (context, i) {
        final m = methods[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.indigo.withOpacity(0.12),
              child: const Icon(Icons.route, color: Colors.indigo),
            ),
            title: Row(
              children: [
                Expanded(
                  child: Text(
                    m.title,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                if (m.isNew) const NewBadge(),
              ],
            ),
            subtitle: Text(
              m.summary,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => MethodDetailPage(method: m)),
            ),
          ),
        );
      },
    );
  }
}

class MethodDetailPage extends StatelessWidget {
  final MethodItem method;
  const MethodDetailPage({super.key, required this.method});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Method')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            method.title,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 8),
          Text(
            method.summary,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Colors.grey.shade700,
                ),
          ),
          const Divider(height: 32),
          for (var i = 0; i < method.steps.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 13,
                    backgroundColor: Colors.indigo,
                    child: Text(
                      '${i + 1}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      method.steps[i],
                      style: const TextStyle(fontSize: 15, height: 1.4),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Offers tab
// ---------------------------------------------------------------------------
class OffersTab extends StatelessWidget {
  final List<OfferItem> offers;
  const OffersTab({super.key, required this.offers});

  @override
  Widget build(BuildContext context) {
    if (offers.isEmpty) {
      return const Center(child: Text('No offers right now. Check back soon.'));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: offers.length,
      itemBuilder: (context, i) {
        final o = offers[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.card_giftcard, color: Colors.indigo),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        o.tool,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ),
                    if (o.isNew) const NewBadge(),
                  ],
                ),
                const SizedBox(height: 8),
                Text(o.whatFree, style: const TextStyle(height: 1.4)),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Chip(
                      avatar: const Icon(Icons.event, size: 16),
                      label: Text(
                        o.expiry.isEmpty ? 'See offer' : o.expiry,
                        style: const TextStyle(fontSize: 12),
                      ),
                    ),
                    const Spacer(),
                    FilledButton.icon(
                      icon: const Icon(Icons.open_in_new, size: 16),
                      label: const Text('Open Offer'),
                      onPressed: () async {
                        await AdGate.maybeShow(context);
                        if (context.mounted) await openLink(context, o.url);
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// Coupons tab
// ---------------------------------------------------------------------------
class CouponsTab extends StatelessWidget {
  final List<CouponItem> coupons;
  const CouponsTab({super.key, required this.coupons});

  @override
  Widget build(BuildContext context) {
    if (coupons.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'No coupons right now — check back soon.\n'
            'Only working, verified codes are listed here.',
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: coupons.length,
      itemBuilder: (context, i) {
        final c = coupons[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.discount, color: Colors.indigo),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        c.store,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ),
                    if (c.isNew) const NewBadge(),
                  ],
                ),
                if (c.description.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text(c.description),
                ],
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 10,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.indigo.withOpacity(0.07),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: Colors.indigo.withOpacity(0.25),
                          ),
                        ),
                        child: Text(
                          c.code,
                          style: const TextStyle(
                            fontFamily: 'monospace',
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    FilledButton.icon(
                      icon: const Icon(Icons.copy, size: 16),
                      label: const Text('Copy'),
                      onPressed: () async {
                        await Clipboard.setData(ClipboardData(text: c.code));
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Coupon code copied'),
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
                if (c.expiry.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(
                    'Expires: ${c.expiry}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}
